package com.example.rfumobileapp;

public interface CallbackFragment {
    void changeFragment();
}
